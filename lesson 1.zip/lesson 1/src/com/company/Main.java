package com.company;

public class Main {

    public static void main(String[] args) {

//        int a = 10;
//        int b = 3;
//        int c = a % b;
//        System.out.println(c);
////        c = c + 5;
//        //Короткая запись
//        c += 10;
//        System.out.println(c);
//        //Площадь квадрата
//        int a2 = 5;
//        a2 *= 5;
//        System.out.println("Площадь квадрата равна: " + a2);
//
//        String name = "Dastan";
//        System.out.println(name);

        // S = pi * r * r
        double pi = 3.14;
        double r = 10.8;
        double s = pi * r * r;
        System.out.println(s);

        float pi2 = 3.14f;
        float r2 = 10.8f;
        float s2 = pi2 * r2 * r2;
        System.out.println(s2);

        final int h = 10;
//        h = h =1;
        int j = 20;


        boolean b = h < j;
        System.out.println(b);

    }
}
